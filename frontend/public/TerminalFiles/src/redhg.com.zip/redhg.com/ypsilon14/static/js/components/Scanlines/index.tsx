import React, { FC } from "react";
import "./style.scss";

const Scanlines: FC = () => <section className="__scanlines__" />;

export default Scanlines;
